package com.casa.ex03;

import com.casa.ex03.Caneta;

public class Aula03 {

	public static void main(String[] args) {

		Caneta c1 = new Caneta("Bic", "Azul", 1.2f);
		Caneta c2 = new Caneta("Nihj", "Branca", 1.7f);
		c1.status();
		c2.status();

	}

}
