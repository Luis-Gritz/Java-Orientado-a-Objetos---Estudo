package com.casa.ex11;

import com.opet.util.Reader;

public class Main {

	public static void main(String[] args) {

		Pessoa p1 = new Pessoa();
		Aluno p2 = new  Aluno();
		Professor p3 = new Professor();
		Funcionario p4 = new Funcionario();
		
		p1.setNome("Luis");
		p1.setIdade(12);
		p1.setSexo("Masculino");
		
		p2.setNome("Foguinho");
		p2.setCurso("Matematica");
		p2.setMatr(1209);
		
		p3.setNome("Carlos");
		p3.setEspecialidade("Otorino");
		p3.setSalario(12000);
		p3.ReceberAum(120);
		
		p4.setNome("Patrick");
		p4.setSetor("Azul");
		p4.mudarTrabalho();
		
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		System.out.println(p3.toString());
		System.out.println(p4.toString());
		
		

	}
	
	public void menuPrincipal() {
		
		
	}

	public int  menuCadastro() throws Exception {

		int opc = -1;

		System.out.println("=====Menu Cadastro=====");
		System.out.println("1 - Cadstrar Aluno");
		System.out.println("2 - Cadastrar Professor");
		System.out.println("0 - Voltar");
		System.out.println("========>");

		opc = Reader.readInt();
		return opc;
	}

}
