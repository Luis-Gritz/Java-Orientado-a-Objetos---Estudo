package com.casa.ex05;

public class Aula05 {

	public static void main(String[] args) {
		
		ControleRemoto c1 = new ControleRemoto();
		
		c1.ligar();
		c1.play();
		c1.maisVolume();
		c1.abrirMenu();
		c1.ligarMudo();
		c1.abrirMenu();

	}

}
